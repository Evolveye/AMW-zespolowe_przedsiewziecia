# Przestrzeń backendu
Jedyną osobą która tutaj pracuje jest Adam Szreiber
