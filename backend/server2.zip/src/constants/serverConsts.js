export const PORT = 3000;
export const APP_ROOT_DIR = import.meta.url.match(/(.*)\//)[1].substr(8).replace('/src/constants','');

