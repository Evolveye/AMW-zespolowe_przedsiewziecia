export default  {
    "COLLECTION_NOT_EXIST": "Collection not exist.",
    "FIELD_NOT_EXIST":"Collection doesn't contain required field.",
    "COLLECTION_FIELD_COUNT":"Required more fields in collection.",
}